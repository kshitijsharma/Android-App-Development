package com.kshitij.applicationlifecycle

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class ActivityLogin : AppCompatActivity() {


    lateinit var username: EditText
    lateinit var password: EditText
    lateinit var loginbutton: Button
    lateinit var forgotp: TextView
    lateinit var register: TextView
    val validMobileNumber="0123456789"
    val validPassword= arrayOf("tony","steve","bruce","thanos")

    lateinit var sharedPreferences: SharedPreferences


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedPreferences = getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)

        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn",false)
        setContentView(R.layout.activity_login)
        if(isLoggedIn)
        {
            val intent =Intent(this@ActivityLogin,AvengersActivity::class.java)
            startActivity(intent)
            finish()
        }



        setContentView(R.layout.activity_login)
        title="LOG IN"

        username = findViewById(R.id.username)
        password = findViewById(R.id.password)
        loginbutton = findViewById(R.id.loginbutton)
        forgotp = findViewById(R.id.forgotp)
        register = findViewById(R.id.register)



        loginbutton.setOnClickListener {
            val mobileNumber =username.text.toString()
            val passwordnew = password.text.toString()
            var nameofavenger = "Avenger"
            val intent = Intent(this@ActivityLogin, AvengersActivity::class.java)

            if(mobileNumber == validMobileNumber){
                if(passwordnew==validPassword[0])
                {

                    nameofavenger ="IRON MAN"
                    savePreference(nameofavenger)
                    startActivity(intent)
                }
                else if(passwordnew==validPassword[1])
                {

                    nameofavenger ="CAPTAIN ROGERS"
                    savePreference(nameofavenger)
                    startActivity(intent)
                }
                else if(passwordnew==validPassword[2])
                {

                    nameofavenger ="HULK"
                    savePreference(nameofavenger)
                    startActivity(intent)
                }
                else if(passwordnew==validPassword[3])
                {

                    nameofavenger ="THANOS"
                    savePreference(nameofavenger)
                    startActivity(intent)
                }
                Toast.makeText(
                    this@ActivityLogin,
                    " WELCOME!",
                    Toast.LENGTH_LONG
                ).show()
            }
            else{
                Toast.makeText(
                    this@ActivityLogin,
                    " INVALID CREDENTIALS TRY AGAIN!!",
                    Toast.LENGTH_LONG
                ).show()

            }
        }
    }

    override fun onPause() {
        super.onPause()
        finish()
    }

    fun savePreference(title: String){
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
        sharedPreferences.edit().putString("Title",title).apply()
    }


}
