package com.kshitij.bookhub.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.kshitij.bookhub.fragment.FavouriteFragment
import com.kshitij.bookhub.R
import com.kshitij.bookhub.fragment.aboutappfragment
import com.kshitij.bookhub.fragment.dashboardfragment
import com.kshitij.bookhub.fragment.profilefragment


class MainActivity : AppCompatActivity() {

    lateinit var drawerLayout: DrawerLayout
    lateinit var coordinatorlayout: CoordinatorLayout
    lateinit var toolbar: Toolbar
    lateinit var frameLayout: FrameLayout
    lateinit var navigationview: NavigationView

    var previousmenuitem : MenuItem? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawerlayout)
        coordinatorlayout = findViewById(R.id.coordinatorlayout)
        toolbar = findViewById(R.id.toolbar)
        frameLayout = findViewById(R.id.frame)
        navigationview = findViewById(R.id.navigationview)
        setUpToolbar()
        opendashboard()

        var actionBarDrawerToggle = ActionBarDrawerToggle(this@MainActivity,drawerLayout,
            R.string.open_drawer,
            R.string.close_drawer
        )
        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()

        navigationview.setNavigationItemSelectedListener {

            if(previousmenuitem != null) {
                previousmenuitem?.isChecked = false
            }

            it.isCheckable = true
            it.isChecked = true
            previousmenuitem =it


            when(it.itemId){
                R.id.dashboard -> {
                    Toast.makeText(this@MainActivity, "Clicked on Dashboard", Toast.LENGTH_SHORT).show()
                    opendashboard()

                }
                R.id.fav -> {
                    Toast.makeText(this@MainActivity, "Clicked on favourites", Toast.LENGTH_SHORT).show()
                    supportFragmentManager.beginTransaction().replace(
                        R.id.frame,
                        FavouriteFragment()
                    ).commit()
                    supportActionBar?.title="FAVOURITE"
                    drawerLayout.closeDrawers()
                }
                R.id.profile -> {
                    Toast.makeText(this@MainActivity, "Clicked on profile", Toast.LENGTH_SHORT).show()
                    supportFragmentManager.beginTransaction().replace(
                        R.id.frame,
                        profilefragment()
                    ).commit()
                    supportActionBar?.title="PROFILE"
                    drawerLayout.closeDrawers()
                }
                R.id.aboutapp -> {
                    Toast.makeText(this@MainActivity, "Clicked on About App", Toast.LENGTH_SHORT).show()
                    supportFragmentManager.beginTransaction().replace(
                        R.id.frame,
                        aboutappfragment()
                    ).commit()
                    supportActionBar?.title="ABOUT APP"
                    drawerLayout.closeDrawers()
                }
            }
            return@setNavigationItemSelectedListener true

        }
    }

    fun setUpToolbar(){
        setSupportActionBar(toolbar)
        supportActionBar?.title = "BOOK HUB"
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId

        if(id == android.R.id.home){
            drawerLayout.openDrawer(GravityCompat.START)
        }
        return super.onOptionsItemSelected(item)
    }

    fun opendashboard(){
        val fragment = dashboardfragment()
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.frame, fragment)
        transaction.commit()
        supportActionBar?.title = "DASHBOARD"
        navigationview.setCheckedItem(R.id.dashboard)
    }

    override fun onBackPressed() {
        val frag = supportFragmentManager.findFragmentById(R.id.frame)

        when(frag){
            !is dashboardfragment -> opendashboard()

            else -> super.onBackPressed()
        }
    }

}
